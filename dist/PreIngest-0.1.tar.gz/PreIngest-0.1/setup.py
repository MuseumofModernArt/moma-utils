from distutils.core import setup

setup(
    name='PreIngest',
    version='0.1',
    packages=['preingest',],
    license='MIT',
)